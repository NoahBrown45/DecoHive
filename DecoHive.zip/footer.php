	<div class="footer">
     <img class="footer-logo" src="Images/Hive.png" />
      <div class="footer-columns">
      	<div class="footer-column">
      		<ul class="footer-column-items">
      			<li class="footer-column-header">About Us</li>
      			<li class="footer-column-item"><a href="http://www.google.com/">How It Works</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">About Us</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Shop With Purpose</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">The Daily Buzz</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Emma's Picks</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Blog</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Terms Of Services</a></li>
      		</ul>
      	</div>
      	<div class="footer-column">
      		<ul class="footer-column-items">
      			<li class="footer-column-header">Join Us</li>
      			<li class="footer-column-item"><a href="http://www.google.com/">My Account</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Member Signup</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Merchant Signup</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Affiliate Signup</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Member Login</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Merchant Login</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Affiliate Login</a></li>
      		</ul>
      	</div>
      	<div class="footer-column">
      		<ul class="footer-column-items">
      			<li class="footer-column-header">Contact Us</li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Web Support</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Merchant Support</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Affiliate Support</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Member Services</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Blog Questions</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Press Contact</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">FAQ</a></li>
      		</ul>
      	</div>
      	<div class="footer-column">
      		<ul class="footer-column-items">
      			<li class="footer-column-header">Connect With Us</li>
      			<li class="footer-column-item"><a href="https://www.facebook.com/pages/DecoHive/734509459973022" target="_blank">Facebook</a></li>
      			<li class="footer-column-item"><a href="https://twitter.com/DecoHive" target="_blank">Twitter</a></li>
      			<li class="footer-column-item"><a href="https://www.youtube.com/channel/UC3jHMojWELgE4gq_aiE0JrQ/about" target="_blank">Youtube</a></li>
      			<li class="footer-column-item"><a href="https://vine.co/u/1144450577418657792" target="_blank">Vine</a></li>
      			<li class="footer-column-item"><a href="https://plus.google.com/b/100065769364491590550/100065769364491590550/about?hl=en&service=PLUS" target="_blank">Google +</a></li>
      			<li class="footer-column-item"><a href="http://www.pinterest.com/DecoHiveDecor/" target="_blank">Pinterest</a></li>
      			<li class="footer-column-item"><a href="http://Instagram.com/decohive/" target="_blank">Instagram</a></li>
      		</ul>
      	</div>
      	<div class="footer-column">
      		<ul class="footer-column-items">
      			<li class="footer-column-header">Explore Us</li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Decor Hive</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Style Hive</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Eco Hive</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Cuisine Hive</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Kinder Hive</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Bridal Hive</a></li>
      			<li class="footer-column-item"><a href="http://www.google.com/">Pet Hive</a></li>
      		</ul>
      	</div>
      </div>
    </div>
  </body>
</html>