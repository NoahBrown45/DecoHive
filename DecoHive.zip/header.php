<html>
	<head>
 		<title>Deco Hive</title>
 		
 		<link rel="shortcut icon" href="http://www.decohive.com/Images/favicon.ico" type="image/png"/>
 		<link rel="stylesheet" type="text/css" href="http://www.decohive.com/Styles/MainStyles.css" />
 	</head>
  
	<body>
	
  		<script type="text/javascript" src="jquery-1.11.2.min.js"></script>
  		<script type="text/javascript" src="http://www.DecoHive.com/CKEditor/ckeditor.js"></script>
  
    	<div class="header">
    		<span class="top-nav-bar">
    			<a class='top-nav-link' href="http://decohive.com/login.php" >How It Works</a>
    			<a class='top-nav-link' href="http://decohive.com/login.php" >Find Your Style</a>
    			<a class='top-nav-link' href="http://decohive.com/login.php" >Shop With Purpose</a>
    			<a class='top-nav-link' href="http://decohive.com/login.php" >The Daily Buzz</a>
    			<a class='top-nav-link' href="http://decohive.com/login.php" >Our Blog</a>
    			<a class='top-nav-link' href="http://decohive.com/login.php" >Login/Signup</a>
    		</span>
      		<span class="login-bar">
      			
      		</span>
    	</div>
    	<div class="blocking-bar">
    		<div class="Logo-Holder">
    			<a href="http://www.decohive.com/">
    				<img class='logo' src='Images/DecoHiveLogo.png' />
    			</a>
    		</div>
    	</div>