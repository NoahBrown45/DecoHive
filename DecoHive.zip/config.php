<?php
	$user = "admin";
	$pass = "password";
	
	$loggedUserName = "";
?>